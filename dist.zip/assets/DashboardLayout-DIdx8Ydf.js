const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-DkRhOznH.js","assets/index-DEQY5Q6r.css"])))=>i.map(i=>d[i]);
import{c as t,r,j as e,L as f,S as o,_ as $,f as L}from"./index-DkRhOznH.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],E=t("calendar",S);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],T=t("chevron-down",O);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],I=t("chevron-right",R);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],D=t("download",U);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]],P=t("file-text",H);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],B=t("log-out",A);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],h=t("map-pin",q);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=[["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 18h16",key:"19g7jn"}],["path",{d:"M4 6h16",key:"1o0s65"}]],V=t("menu",K);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],g=t("trending-up",F);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],y=t("users",G);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Y=t("x",X),J=({children:k})=>{const[x,a]=r.useState(!1),[c,j]=r.useState(null),[d,m]=r.useState(!1),u=sessionStorage.getItem("username")||"Pengguna";r.useEffect(()=>{j(sessionStorage.getItem("userRole"))},[]);const v=()=>{o.fire({title:"Yakin logout?",icon:"warning",showCancelButton:!0,confirmButtonText:"Ya!",cancelButtonText:"Batal"}).then(s=>s.isConfirmed&&L())},N=s=>{s.preventDefault(),o.fire("Segera Hadir!","Fitur dalam pengembangan.","info"),a(!1)},b=async s=>{try{o.fire({title:"Mengekspor...",text:`Menyiapkan ${s}`,allowOutsideClick:!1,showConfirmButton:!1,willOpen:()=>o.showLoading()});const n=await(await $(async()=>{const{default:C}=await import("./index-DkRhOznH.js").then(z=>z.k);return{default:C}},__vite__mapDeps([0,1]))).default.get(`/export/${s}`,{responseType:"blob"}),M=new Blob([n.data],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),p=URL.createObjectURL(M),i=document.createElement("a");i.href=p,i.download=`${s}_${new Date().toISOString().slice(0,10)}.xlsx`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(p),o.fire("Berhasil!",`${s} berhasil diunduh.`,"success"),m(!1),a(!1)}catch(l){let n="Gagal mengekspor data.";l.response?.status===404?n="Endpoint tidak ditemukan.":l.response?.status===403?n="Tidak ada akses.":l.response?.data?.message&&(n=l.response.data.message),o.fire("Gagal!",n,"error")}},w=c==="admin"?[{to:"/admin/dashboard",label:"Dashboard",icon:g},{to:"/admin/teams",label:"Tim Sales",icon:y},{to:"/admin/PageIzin",label:"Pengajuan Izin",icon:y},{to:"#",label:"Lokasi Kantor",icon:h,soon:!0},{to:"#",label:"Laporan",icon:P,soon:!0}]:[{to:"/sales/dashboard",label:"Dashboard",icon:g},{to:"/sales/kunjungan",label:"Kunjungan",icon:h}],_=s=>window.location.pathname===s;return e.jsxs("div",{className:"flex h-screen bg-gray-50",children:[e.jsxs("div",{className:`fixed inset-y-0 left-0 z-[1000] w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white transform ${x?"translate-x-0":"-translate-x-full"} transition-transform duration-200 lg:translate-x-0 lg:static`,children:[e.jsxs("div",{className:"flex items-center justify-between h-16 px-6 border-b border-blue-700",children:[e.jsx("h1",{className:"text-xl font-bold",children:"TEKMO 😎"}),e.jsx("button",{onClick:()=>a(!1),className:"lg:hidden",children:e.jsx(Y,{size:24})})]}),e.jsxs("nav",{className:"mt-8",children:[e.jsx("div",{className:"px-6 py-3",children:e.jsx("p",{className:"text-blue-200 text-sm font-medium",children:"MENU UTAMA"})}),w.map(s=>s.soon?e.jsxs("button",{onClick:N,className:"flex w-full items-center px-6 py-3 text-blue-100 hover:bg-blue-700 hover:text-white transition-colors",children:[e.jsx(s.icon,{size:20,className:"mr-3"}),s.label]},s.label):e.jsxs(f,{to:s.to,className:`flex items-center px-6 py-3 transition-colors ${_(s.to)?"bg-blue-700 text-white border-r-4 border-blue-400":"text-blue-100 hover:bg-blue-700 hover:text-white"}`,onClick:()=>a(!1),children:[e.jsx(s.icon,{size:20,className:"mr-3"}),s.label]},s.to)),c==="admin"&&e.jsxs("div",{className:"mt-4",children:[e.jsx("div",{className:"px-6 py-3",children:e.jsx("p",{className:"text-blue-200 text-sm font-medium",children:"EXPORT"})}),e.jsxs("button",{onClick:()=>m(!d),className:"flex w-full items-center justify-between px-6 py-3 text-blue-100 hover:bg-blue-700 hover:text-white transition-colors",children:[e.jsxs("div",{className:"flex items-center",children:[e.jsx(D,{size:20,className:"mr-3"}),"Excel"]}),d?e.jsx(T,{size:16}):e.jsx(I,{size:16})]}),d&&e.jsxs("div",{className:"bg-blue-800 border-t border-blue-700",children:[e.jsxs("button",{onClick:()=>b("absensi"),className:"flex w-full items-center px-12 py-3 text-blue-100 hover:bg-blue-700 hover:text-white transition-colors text-sm",children:[e.jsx(E,{size:16,className:"mr-3"}),"Absensi"]}),e.jsxs("button",{onClick:()=>b("kunjungan"),className:"flex w-full items-center px-12 py-3 text-blue-100 hover:bg-blue-700 hover:text-white transition-colors text-sm",children:[e.jsx(h,{size:16,className:"mr-3"}),"Kunjungan"]})]})]}),e.jsxs("button",{onClick:v,className:"flex w-full items-center px-6 py-3 text-blue-100 hover:bg-blue-700 hover:text-white transition-colors mt-8",children:[e.jsx(B,{size:20,className:"mr-3"}),"Keluar"]})]})]}),x&&e.jsx("div",{className:"fixed inset-0 z-[999] bg-black bg-opacity-25 lg:hidden",onClick:()=>a(!1)}),e.jsxs("div",{className:"flex-1 flex flex-col overflow-hidden",children:[e.jsx("header",{className:"bg-white shadow-sm border-b border-gray-200",children:e.jsx("div",{className:"mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"flex items-center justify-between h-16",children:[e.jsxs("div",{className:"flex items-center",children:[e.jsx("button",{onClick:()=>a(!0),className:"lg:hidden text-gray-500 hover:text-gray-600 mr-3",children:e.jsx(V,{size:24})}),e.jsx("h1",{className:"text-lg font-medium text-gray-800 hidden sm:block",children:"Selamat datang bosku 😍"}),e.jsx("h1",{className:"text-base font-medium text-gray-800 sm:hidden",children:"welcome bos"})]}),e.jsxs("div",{className:"flex items-center space-x-4",children:[e.jsxs("div",{className:"text-right",children:[e.jsx("p",{className:"font-semibold text-sm text-gray-800",children:u}),e.jsx("p",{className:"text-xs text-gray-500 capitalize",children:c})]}),e.jsx(f,{to:"/profile",children:e.jsx("div",{className:"w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold",children:u.charAt(0).toUpperCase()})})]})]})})}),e.jsx("main",{className:"flex-1 overflow-y-auto p-4 sm:p-6",children:k})]})]})};export{E as C,J as D,P as F,h as M,g as T,Y as X,T as a};
