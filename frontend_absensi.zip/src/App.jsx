// src/App.jsx

import React, { useEffect, useRef, useState, useCallback, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { isAuthenticated, getUserRole, logout } from './api/auth.js';
import Swal from 'sweetalert2';

// Import komponen lazy loading seperti biasa
const AdminTeamPage = React.lazy(() => import('./pages/Admin/TimSales.jsx'));
const LoginPage = React.lazy(() => import('./pages/LoginPage.jsx'));
const DashboardAdmin = React.lazy(() => import('./pages/Admin/Dashboard.jsx'));
const DashboardSales = React.lazy(() => import('./pages/Sales/Dashboard.jsx'));
const PageIzin = React.lazy(() => import('./pages/Admin/PageIzin.jsx'));
const NotFoundPage = React.lazy(() => import('./pages/NotFoundPage.jsx'));
const TrackingPage = React.lazy(() => import('./pages/Admin/TrackingPage'));
const KunjunganPage = React.lazy(() => import('./pages/Sales/Kunjungan.jsx'));
const ProfilePage = React.lazy(() => import('./pages/Profilepage.jsx'));
const ForgotPasswordPage = React.lazy(() => import('./pages/ForgotPasswordPage'));
const ResetPasswordPage = React.lazy(() => import('./pages/ResetPasswordPage'));
import ProtectedRoute from './components/ProtectedRoute.jsx'; // Import statis

// ... (kode DashboardDispatcher, handleAutoLogout, dan lainnya tetap sama)

function App() {
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(isAuthenticated());
  const [userRole, setUserRole] = useState(null);
  const timeoutId = useRef(null);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const listenersSetup = useRef(false);

  useEffect(() => {
    const role = sessionStorage.getItem('userRole');
    setUserRole(role);
  }, []);

  const handleAutoLogout = useCallback(async () => {
    if (isLoggingOut) return;
    setIsLoggingOut(true);
    
    try {
      if (timeoutId.current) {
        clearTimeout(timeoutId.current);
        timeoutId.current = null;
      }
      listenersSetup.current = false;
      await Swal.fire({
        title: 'Sesi Berakhir',
        text: 'Anda tidak aktif selama 1 menit. Sesi akan berakhir.',
        icon: 'warning',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
        allowEscapeKey: false
      });
      logout();
      setTimeout(() => {
        setIsUserLoggedIn(false);
        setIsLoggingOut(false);
      }, 100);
    } catch (error) {
      console.error('Error during auto logout:', error);
      setIsLoggingOut(false);
    }
  }, [isLoggingOut]);

  const resetTimeout = useCallback(() => {
    if (isLoggingOut || !isUserLoggedIn) return;
    if (timeoutId.current) {
      clearTimeout(timeoutId.current);
    }
    timeoutId.current = setTimeout(() => {
      handleAutoLogout();
    }, 1 * 60 * 1000);
    if (Math.random() < 0.01) {
      console.log("Timer reset");
    }
  }, [isLoggingOut, isUserLoggedIn, handleAutoLogout]);

  useEffect(() => {
    if (!isUserLoggedIn || isLoggingOut || listenersSetup.current) {
      return;
    }
    console.log("Setting up activity listeners...");
    const events = ['mousedown', 'keydown', 'touchstart', 'scroll'];
    events.forEach(event => {
      document.addEventListener(event, resetTimeout, { passive: true });
    });
    listenersSetup.current = true;
    resetTimeout();
    return () => {
      console.log("Cleaning up activity listeners...");
      events.forEach(event => {
        document.removeEventListener(event, resetTimeout);
      });
      if (timeoutId.current) {
        clearTimeout(timeoutId.current);
        timeoutId.current = null;
      }
      listenersSetup.current = false;
    };
  }, [isUserLoggedIn, isLoggingOut, resetTimeout]);

  useEffect(() => {
    const checkAuthStatus = () => {
      if (isLoggingOut) return;
      const currentAuthStatus = isAuthenticated();
      if (currentAuthStatus !== isUserLoggedIn) {
        console.log("Auth status changed:", currentAuthStatus);
        setIsUserLoggedIn(currentAuthStatus);
        if (!currentAuthStatus && timeoutId.current) {
          clearTimeout(timeoutId.current);
          timeoutId.current = null;
          listenersSetup.current = false;
        }
      }
    };
    checkAuthStatus();
    window.addEventListener('authStatusChanged', checkAuthStatus);
    return () => {
      window.removeEventListener('authStatusChanged', checkAuthStatus);
    };
  }, [isUserLoggedIn, isLoggingOut]);

  useEffect(() => {
    return () => {
      if (timeoutId.current) {
        clearTimeout(timeoutId.current);
      }
    };
  }, []);

  if (isLoggingOut) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        fontSize: '18px',
        backgroundColor: '#f5f5f5'
      }}>
        <div>
          <div>Sedang logout...</div>
          <div style={{ fontSize: '14px', marginTop: '10px', opacity: 0.7 }}>
            Mohon tunggu sebentar
          </div>
        </div>
      </div>
    );
  }

  const DashboardDispatcher = () => {
    const role = getUserRole();
    if (role === 'admin') return <Navigate to="/admin/dashboard" />;
    if (role === 'sales') return <Navigate to="/sales/dashboard" />;
    return <Navigate to="/" />;
  };

  return (
    <Router>
      <Suspense fallback={
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
          fontSize: '18px',
          backgroundColor: '#f5f5f5'
        }}>
          Sedang memuat...
        </div>
      }>
        <Routes>
          <Route path="/" element={isUserLoggedIn ? <DashboardDispatcher /> : <LoginPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          
          <Route path="/dashboard" element={<ProtectedRoute><DashboardDispatcher /></ProtectedRoute>} />
          <Route path="/admin/dashboard" element={<ProtectedRoute requiredRole="admin"><DashboardAdmin /></ProtectedRoute>} />
          <Route path="/admin/teams" element={<ProtectedRoute requiredRole="admin"><AdminTeamPage /></ProtectedRoute>} />
          <Route path="/admin/PageIzin" element={<ProtectedRoute requiredRole="admin"><PageIzin /></ProtectedRoute>} />
          <Route path="/admin/tracking/:username" element={<ProtectedRoute><TrackingPage /></ProtectedRoute>} />
          <Route path="/sales/dashboard" element={<ProtectedRoute requiredRole="sales"><DashboardSales /></ProtectedRoute>} />
          <Route path="/sales/kunjungan" element={<ProtectedRoute requiredRole="sales"><KunjunganPage /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
    </Router>
  );
}

export default App;